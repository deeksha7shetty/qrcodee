import qrcode
qr = qrcode.QRCode(
    version = 10,
    box_size = 10,
    border = 5
)

data = "https://www.linkedin.com/feed/"
qr.add_data(data)
qr.make(fit = True)
img = qr.make_image(fill = "black",back_color = "white")
img.save("t.png")


# 1.run pip install qrcode
# 2.pip list
# 3.enter the code in any python file.
# 4.cd downloads(file should be present in downloads)
# 5.cd qr(this is a folder where python file i s present)
# 6.python qrcodee.py 
# Program will be executed.